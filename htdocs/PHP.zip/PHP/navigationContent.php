<?php
echo "
        <a class=\"navlinkA\" href=\"".$path."AboutUs.php\">About Us</a></br></br>
        <a class=\"navlinkA\" href=\"".$path."Media.php\">Media</a></br></br>
        <a class=\"navlinkA\" href=\"".$path."Minecraft.php\">Minecraft!</a></br></br>
    ";
?>