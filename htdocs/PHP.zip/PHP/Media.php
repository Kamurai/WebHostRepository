<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Frameset//EN" "http://www.w3.org/TR/html4/frameset.dtd">
<html>
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1">
    <link href="./Main.css" rel="stylesheet" type="text/css">
</head>
<font color="white">
<body id="idBody">
<?php
	include 'Path.php';
	
	$title = "Media";
	$centerHeader = "Media";
	$centerContent = "
						You can find us at all these different places:</br>
						<br/>
						<br/>
							#WeAreMovieClub:
						<br/>
						<br/>
							<a href=\"http://www.youtube.com/WeAreMovieClub\">Youtube.com/WeAreMovieClub:  A place for movie discussion.</a></br>
							<a href=\"http://WeAreMovieClub.tumblr.com\">WeAreMovieClub.tumblr.com: We have a tumblr!</a></br>
							<a href=\"http://www.twitter.com/WeAreMovieClub\">@WeAreMovieClub on Twitter: Let us know about your movie thoughts.</a></br>
							<a href=\"http://www.facebook.com/WeAreMovieClub\">facebook.com/WeAreMovieClub: Talk about movie with us.</a></br>
						<br/>
						<br/>
							HTKB Productions
						<br/>
						<br/>
							<a href=\"http://www.youtube.com/GamingDivision528\">Gaming Division:  A Youtube Channel for game stuff.</a></br>
							<a href=\"http://www.youtube.com/JamOnToast528\">Jam On Toast:  A Youtube Channel for media stuff.</a></br>
							<a href=\"http://www.ustream.tv/HTKB\">UStream:  Streams show up here too.</a></br>
							<a href=\"http://www.firetalk.com/HTKB\">FireTalk:  Streams show up here too.</a></br>
							<a href=\"http://www.younow.com/HTKB\">YouNow:  Streams show up here too.</a></br>
							<a href=\"http://www.soundcloud.com/HTKB\">Sound Cloud:  Listen to our podcasts.</a></br>
							<a href=\"http://HTKB.podbean.com/\">Pod Bean:  Listen to our podcasts.</a></br>
							<a href=\"http://www.youtube.com/HTKB\">Youtube:  Thoughts and life discussions.</a></br>
							<a href=\"http://www.patreon.com/HTKBProductions\">Patreon:  You can help make our dreams reality.</a></br>
							<a href=\"http://www.facebook.com/HouseThatKamuraiBuilt\">Facebook: Talk about movie with us.</a></br>
							<a href=\"http://HouseThatKamuraiBuilt.tumblr.com\">HouseThatKamuraiBuilt.tumblr.com: We have a tumblr!</a></br>
							<a href=\"http://myspace.com/HouseThatKamuraiBuilt\">Myspace: Wow, there's even a MySpace!</a></br>
						<br/>
							Here are some of our member's pages:</br>
						<br/>
								Kamurai:
						<br/>
						<br/>
							<a href=\"http://twitter.com/#!/Kamurai25\">Kamurai's Twitter.</a></br>
							<a href=\"http://Instagram.com/Kamurai25\">Kamurai's Instagram.</a></br>
							<a href=\"./.\">Kamurai's Snapchat: Kamurai</a></br>
							<a href=\"http://www.facebook.com/cris.kamurai\">Kamurai's Facebook.</a></br>
							<a href=\"https://www.gplus.com/Members/Cris-Kamurai\">Kamurai's Google Plus.</a></br>
							<a href=\"http://www.yoyogames.com/users/Kamurai\">Kamurai's YoYo Games page:  See some of the games he's posted.</a></br>
						
                    ";
	$GDR = "";
	$winrar = "";

	$infoContent = "This is written with PHP.<br><br>
					Other versions of this page are here:<br>
					<a href=\"http://htkb.dyndns.org/Media.html\">HTML</a><br>
					<a href=\"http://htkb.dyndns.org/Javascript/Media.html\">HTML Javascript</a><br>
					<a href=\"http://htkb.dyndns.org:81/ASP/Media.asp\">ASP Javascript</a><br>
					<a href=\"http://htkb.dyndns.org:81/ASPNET/Media.aspx\">ASP.NET Javascript</a><br>
					<a href=\"http://htkb.dyndns.org/Media.shtml\">Perl</a><br>
					<a href=\"http://htkb.dyndns.org:8080/JSPApplication/Media.jsp\">JSP</a><br>
					<a href=\"http://htkb.dyndns.org:8080/JSFApplication/Media.xhtml\">JSF</a><br>
					<a href=\"http://htkb.dyndns.org:81/WebApplication/Media.cshtml\">ASP.NET Web App</a><br>
					<a href=\"http://htkb.dyndns.org:81/WebForm/Media.aspx\">ASP.NET Webform</a><br>
					<a href=\"http://htkb.dyndns.org:81/MVC/Main/Media\">ASP.NET MVC App</a><br>
					<a href=\"http://htkb.dyndns.org/SSI/Media.html\">Apache SSI</a><br>
				";
	
	#Overall body
	include $style.'Layout.php';
?>
</body>
</font>
</html>