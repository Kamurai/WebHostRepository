<?php
echo "
		<a class=\"navBar\" href='".$path."index.php'>Home</a>
		<a class=\"navBar\" href='".$path."Section1/index.php'>Web Programming</a>
		<a class=\"navBar\" href='".$path."Section2/index.php'>Private Projects</a>
		<a class=\"navBar\" href='".$path."Section3/index.php'>Downloadable Projects</a>
   ";
?>