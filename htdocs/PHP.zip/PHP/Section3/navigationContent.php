<?php
echo "
		<a class=\"navlinkA\" href=\"".$path."Section3/Project1.php\">Online Experience Downloads</a></br></br>
        <a class=\"navlinkA\" href=\"".$path."Section3/Project2.php\">Game Maker Downloads</a></br></br>
        <a class=\"navlinkA\" href=\"".$path."Section3/Project3.php\">Java Downloads</a></br></br>
        <a class=\"navlinkA\" href=\"".$path."Section3/Project4.php\">C# Downloads</a></br></br>
        <a class=\"navlinkA\" href=\"".$path."Section3/Project5.php\">C++ Downloads</a></br></br>
	";
?>