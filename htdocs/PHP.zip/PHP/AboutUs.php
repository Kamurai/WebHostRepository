<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Frameset//EN" "http://www.w3.org/TR/html4/frameset.dtd">
<html>
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1">
    <link href="./Main.css" rel="stylesheet" type="text/css">
</head>
<font color="white">
<body id="idBody">
<?php
	include "Path.php";
	
	$title = "About Us";
	$centerHeader = "About Us";
	$centerContent = "
						We are working to build this into a better place.</br>
						If you found this, then you must be at least (Awesome/2).</br>
						Stay tuned, right now it\"s all about laying foundation for the future.</br>
						
					";
	$GDR = "";
	$winrar = "";
	
	$infoContent = "This is written with PHP.<br><br>
					Other versions of this page are here:<br>
					<a href=\"http://htkb.dyndns.org/AboutUs.html\">HTML</a><br>
					<a href=\"http://htkb.dyndns.org/Javascript/AboutUs.html\">HTML Javascript</a><br>
					<a href=\"http://htkb.dyndns.org:81/ASP/AboutUs.asp\">ASP Javascript</a><br>
					<a href=\"http://htkb.dyndns.org:81/ASPNET/AboutUs.aspx\">ASP.NET Javascript</a><br>
					<a href=\"http://htkb.dyndns.org/AboutUs.shtml\">Perl</a><br>
					<a href=\"http://htkb.dyndns.org:8080/JSPApplication/AboutUs.jsp\">JSP</a><br>
					<a href=\"http://htkb.dyndns.org:8080/JSFApplication/AboutUs.xhtml\">JSF</a><br>
					<a href=\"http://htkb.dyndns.org:81/WebApplication/AboutUs.cshtml\">ASP.NET Web App</a><br>
					<a href=\"http://htkb.dyndns.org:81/WebForm/AboutUs.aspx\">ASP.NET Webform</a><br>
					<a href=\"http://htkb.dyndns.org:81/MVC/Main/AboutUs\">ASP.NET MVC App</a><br>
					<a href=\"http://htkb.dyndns.org/SSI/AboutUs.html\">Apache SSI</a><br>
				";
	

	#Overall body
	include $style."Layout.php";
?>
</body>
</font>
</html>