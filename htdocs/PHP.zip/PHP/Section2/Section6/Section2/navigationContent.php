<?php
echo "
			<a class=\"navlinkA\" href='".$path."Section2/Section1/index.php'>Gynowars</a></br></br>
			<a class=\"navlinkA\" href='".$path."Section2/Project2.php'>Assault</a></br></br>
			<a class=\"navlinkA\" href='".$path."Section2/Project3.php'>Mars</a></br></br>
			<a class=\"navlinkA\" href='".$path."Section2/Section4/index.php'>Renley</a></br></br>
			<a class=\"navlinkA\" href='".$path."Section2/Section5/index.php'>Antarrea</a></br></br>
			<a class=\"navlinkA\" href='".$path."Section2/Section6/index.php'>Editations</a></br></br>
				<a class=\"navlinkB\" href='".$path."Section2/Section6/Project1.php'>Magic: The Tactical</a></br></br>
				<a class=\"navlinkB\" href='".$path."Section2/Section6/Section2/index.php'>Warhammer 40K</a></br></br>
					<a class=\"navlinkC\" href='".$path."Section2/Section6/Section2/Project1.php'>Mission!</a></br></br>
					<a class=\"navlinkC\" href='".$path."Section2/Section6/Section2/Section2/index.php'>HTKB Armies</a></br></br>
			<a class=\"navlinkA\" href='".$path."Section2/Project7.php'>Truth</a></br></br>
			<a class=\"navlinkA\" href='".$path."Section2/Project8.php'>Kingdoms</a></br></br>
			<a class=\"navlinkA\" href='".$path."Section2/Project9.php'>Terminal World</a></br></br>
			<a class=\"navlinkA\" href='".$path."Section2/Project10.php'>Monster Office Workplace</a></br></br>
			<a class=\"navlinkA\" href='".$path."Section2/Project11.php'>Battle Princesses</a></br></br>
			<a class=\"navlinkA\" href='".$path."Section2/Project12.php'>Sacred Offerings</a></br></br>
			<a class=\"navlinkA\" href='".$path."Section2/Project13.php'>The Way</a></br></br>
			<a class=\"navlinkA\" href='".$path."Section2/Project14.php'>Conspiratorium</a></br></br>
			<a class=\"navlinkA\" href='".$path."Section2/Project15.php'>Conversion</a></br></br>
	";
?>