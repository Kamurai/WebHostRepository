<?php
	echo "
		<a href='../index.php'>Home</a>
		<a href='../Section1/index.php'>Web Programming</a>
		<a href='../Section2/index.php'>Private Projects</a>
		<a href='../Section3/index.php'>Downloadable Projects</a>
   ";
?>