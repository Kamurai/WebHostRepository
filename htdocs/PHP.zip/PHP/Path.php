<?php
	$path  = "./";
	$style = "./";
?>