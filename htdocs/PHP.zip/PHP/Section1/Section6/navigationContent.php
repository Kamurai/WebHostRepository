<?php
echo "
		<a class=\"navlinkA\" href='".$path."Section1/Project1.html'>Basic HTML</a></br></br>
		<a class=\"navlinkA\" href='".$path."Section1/Project1.php'>PHP</a></br></br>
		<a class=\"navlinkA\" href='".$path."Section1/Section2/Index.php'>Java Script</a></br></br>
		<a class=\"navlinkA\" href='".$path."Section1/Project3.shtml'>Perl</a></br></br>
		<a class=\"navlinkA\" href='".$path."Section1/Section4/Index.php'>Java</a></br></br>
		<a class=\"navlinkA\" href='".$path."Section1/Section5/Index.php'>ASP.Net</a></br></br>
		<a class=\"navlinkA\" href='".$path."Section1/Section6/Index.php'>Databases</a></br></br>
			<a class=\"navlinkB\" href='".$path."Section1/Section6/Project1.php'>Oracle</a></br></br>
			<a class=\"navlinkB\" href='".$path."Section1/Section6/Project2.php'>Derby</a></br></br>
			<a class=\"navlinkB\" href='".$path."Section1/Section6/Project3.php'>MySQL</a></br></br>
			<a class=\"navlinkB\" href='".$path."Section1/Section6/Project4.php'>SQL Server</a></br></br>
			<a class=\"navlinkB\" href='".$path."Section1/Section6/Project5.php'>Postgres</a></br></br>
		<a class=\"navlinkA\" href='http://htkb.dyndns.org/SSI/Section1/index.html'>Apache SSI</a></br></br>
	";
?>