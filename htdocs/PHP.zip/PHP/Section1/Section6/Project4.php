<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Frameset//EN" "http://www.w3.org/TR/html4/frameset.dtd">
<html>
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1">
</head>
<font color="white">
<body id="idBody">
<?php
	include 'Path.php';
	include $path.'DataMethod.php';
	
	$title = "SQL Server Programming";
	$centerHeader = "SQL Server Programming";
	$centerContent = "
							This section is dedicated to SQL Server based programming.
						</br>
						</br>
							<table>
								<tr>
									<td>
									  SQL Server Instance  
									</td>
									<td></td>
								</tr>
								<tr>
									<td>
										Index
									</td>
									<td>
										Color
									</td>
								</tr>
								<tr>
									<td>
										SQLServerMethod('1','0')
									</td>
									<td>
										SQLServerMethod('Red','1')
									</td>
								</tr>
								<tr>
									<td>
										SQLServerMethod('2','0')
									</td>
									<td>
										SQLServerMethod('Orange','1')
									</td>
								</tr>
								<tr>
									<td>
										SQLServerMethod('3','0')
									</td>
									<td>
										SQLServerMethod('Yellow','1')
									</td>
								</tr>
								<tr>
									<td>
										SQLServerMethod('4','0')
									</td>
									<td>
										SQLServerMethod('Green','1')
									</td>
								</tr>
								<tr>
									<td>
										SQLServerMethod('5','0')
									</td>
									<td>
										SQLServerMethod('Blue','1')
									</td>
								</tr>
								<tr>
									<td>
										SQLServerMethod('6','0')
									</td>
									<td>
										SQLServerMethod('Indigo','1')
									</td>
								</tr>
								<tr>
									<td>
										SQLServerMethod('7','0')
									</td>
									<td>
										SQLServerMethod('Violet','1')
									</td>
								</tr>
								<tr></tr>
								<tr></tr>
								<tr>
									<td>
									  SQL Server Express Instance  
									</td>
									<td></td>
								</tr>
								<tr>
									<td>
										Index
									</td>
									<td>
										Color
									</td>
								</tr>
								<tr>
									<td>
										SQLServerExpressMethod('1','0')
									</td>
									<td>
										SQLServerExpressMethod('Red','1')
									</td>
								</tr>
								<tr>
									<td>
										SQLServerExpressMethod('2','0')
									</td>
									<td>
										SQLServerExpressMethod('Orange','1')
									</td>
								</tr>
								<tr>
									<td>
										SQLServerExpressMethod('3','0')
									</td>
									<td>
										SQLServerExpressMethod('Yellow','1')
									</td>
								</tr>
								<tr>
									<td>
										SQLServerExpressMethod('4','0')
									</td>
									<td>
										SQLServerExpressMethod('Green','1')
									</td>
								</tr>
								<tr>
									<td>
										SQLServerExpressMethod('5','0')
									</td>
									<td>
										SQLServerExpressMethod('Blue','1')
									</td>
								</tr>
								<tr>
									<td>
										SQLServerExpressMethod('6','0')
									</td>
									<td>
										SQLServerExpressMethod('Indigo','1')
									</td>
								</tr>
								<tr>
									<td>
										SQLServerExpressMethod('7','0')
									</td>
									<td>
										SQLServerExpressMethod('Violet','1')
									</td>
								</tr>
							</table>
					";
	$GDR = "";
	$winrar = "";

	$infoContent = "This is written with PHP.<br><br>
					Other versions of this page are here:<br>
					<a href=\"http://htkb.dyndns.org/Section1/Section6/Project4.html\">HTML</a><br>
					<a href=\"http://htkb.dyndns.org/Javascript/Section1/Section6/Project4.html\">HTML Javascript</a><br>
					<a href=\"http://htkb.dyndns.org:81/ASP/Section1/Section6/Project4.asp\">ASP Javascript</a><br>
					<a href=\"http://htkb.dyndns.org:81/ASPNET/Section1/Section6/Project4.aspx\">ASP.NET Javascript</a><br>
					<a href=\"http://htkb.dyndns.org/Section1/Section6/Project4.shtml\">Perl</a><br>
					<a href=\"http://htkb.dyndns.org:8080/JSPApplication/Section1/Section6/Project4.jsp\">JSP</a><br>
					<a href=\"http://htkb.dyndns.org:8080/JSFApplication/Section1/Section6/Project4.xhtml\">JSF</a><br>
					<a href=\"http://htkb.dyndns.org:81/WebApplication/Section1/Section6/Project4.cshtml\">ASP.NET Web App</a><br>
					<a href=\"http://htkb.dyndns.org:81/WebForm/Section1/Section6/Project4.aspx\">ASP.NET Webform</a><br>
					<a href=\"http://htkb.dyndns.org:81/MVC/Main/Section1/Section6/Project4\">ASP.NET MVC App</a><br>
					<a href=\"http://htkb.dyndns.org/SSI/Section1/Section6/Project4.html\">Apache SSI</a><br>
				";
	

	#Overall body
	include $style.'Layout.php';
?>
</body>
</font>
</html>