<?php
	$path  = "../../";
	$style = "../";
?>