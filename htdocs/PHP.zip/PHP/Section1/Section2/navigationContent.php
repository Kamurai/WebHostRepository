<?php
echo "
		<a class=\"navlinkA\" href='".$path."Section1/Project1.html'>Basic HTML</a></br></br>
		<a class=\"navlinkA\" href='".$path."Section1/Project1.php'>PHP</a></br></br>
		<a class=\"navlinkA\" href='".$path."Section1/Section2/Index.php'>Java Script</a></br></br>
			<a class=\"navlinkB\" href='".$path."Javascript/Section1/Section2/Project1.html'>HTML Javascript</a></br></br>
			<a class=\"navlinkB\" href='http://htkb.dyndns.org:81/ASP/Section1/Section2/Project2.asp'>ASP Javascript</a></br></br>
			<a class=\"navlinkB\" href='http://htkb.dyndns.org:81/ASPNET/Section1/Section2/Project3.aspx'>ASP.NET Javascript</a></br></br>
		<a class=\"navlinkA\" href='".$path."Section1/Project3.shtml'>Perl</a></br></br>
		<a class=\"navlinkA\" href='".$path."Section1/Section4/Index.php'>Java</a></br></br>
		<a class=\"navlinkA\" href='".$path."Section1/Section5/Index.php'>ASP.Net</a></br></br>
		<a class=\"navlinkA\" href='".$path."Section1/Section6/Index.php'>Databases</a></br></br>
		<a class=\"navlinkA\" href='http://htkb.dyndns.org/SSI/Section1/index.html'>Apache SSI</a></br></br>
	";
?>