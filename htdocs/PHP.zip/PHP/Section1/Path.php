<?php
	$path  = "../";
	$style = "./";
?>