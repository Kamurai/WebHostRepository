You have this folder if you have ran minecraft on your computer:

C:\Users\*windows user name*\AppData\Roaming\.minecraft\

Backup your .minecraft folder (copy and paste it somewhere)

Copy these folders to your .minecraft folder. Choose replace files.